﻿namespace Neo.Consensus
{
    internal enum PolicyLevel : byte
    {
        AllowAll,
        DenyAll,
        AllowList,
        DenyList
    }
}
